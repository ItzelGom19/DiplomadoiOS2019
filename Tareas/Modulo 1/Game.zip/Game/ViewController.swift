//
//  ViewController.swift
//  Game
//
//  Created by Itzel GoOm on 11/08/18.
//  Copyright © 2018 Itzel GoOm. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var computerSign: UILabel!
    @IBOutlet weak var gameStatus: UILabel!
    
    @IBOutlet weak var rockButton: UIButton!
    @IBOutlet weak var paperButton: UIButton!
    @IBOutlet weak var scissorsButton: UIButton!
    @IBOutlet weak var playAgainButton: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resetGame()
        self.view.backgroundColor = UIColor.cyan

    }

   
    func play(_ playerTurn: Sign) {
        rockButton.isEnabled = false
        paperButton.isEnabled = false
        scissorsButton.isEnabled = false
        
        let opponent = ramdomSign()
        computerSign.text = opponent.emoji
        
        let result = playerTurn.takeTurn(opponent)
        
        switch result {
        case .draw:
            gameStatus.text = "It´s a draw!"
            self.view.backgroundColor = UIColor.brown

        case .lose:
            gameStatus.text = "You lose!"
            self.view.backgroundColor = UIColor.gray

        case .win:
            gameStatus.text = "You Win!!!"
            self.view.backgroundColor = UIColor.yellow

        case .start:
            gameStatus.text = "Rock, Paper, Scissors?"
            self.view.backgroundColor = UIColor.cyan

        }
        
        switch playerTurn {
        case .rock:
            rockButton.isHidden = false
            paperButton.isHidden = true
            scissorsButton.isHidden = true
            
        case .paper:
            rockButton.isHidden = true
            paperButton.isHidden = false
            scissorsButton.isHidden = true
            
        case .scissors:
            rockButton.isHidden = true
            paperButton.isHidden = true
            scissorsButton.isHidden = false
            
        }
        
        playAgainButton.isHidden = false
    }
    
    func resetGame() {
        
        computerSign.text = "😎"
        gameStatus.text = "Rock, Paper, Scissors?"
        rockButton.isHidden = false
        rockButton.isEnabled = true
        paperButton.isHidden = false
        paperButton.isEnabled = true
        scissorsButton.isHidden = false
        scissorsButton.isEnabled = true
        playAgainButton.isHidden = true
        self.view.backgroundColor = UIColor.cyan

    }
    
    @IBAction func rockSelected(_ sender: Any) {
        play(Sign.rock)
    }
    
    @IBAction func paperSelected(_ sender: Any) {
        play(Sign.paper)
    }
    
    @IBAction func scissorsSelected(_ sender: Any) {
        play(Sign.scissors)
    }
    
    
    @IBAction func playAgainSelected(_ sender: Any) {
        resetGame()
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    


    
    
    
    
    
}


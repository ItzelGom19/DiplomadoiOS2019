//
//  GameState.swift
//  Game
//
//  Created by Itzel GoOm on 11/08/18.
//  Copyright © 2018 Itzel GoOm. All rights reserved.
//

import Foundation

enum GameState {
    case start, win, lose, draw 
    
}
